﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using ClassLibrary1;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            string password = "ASDqw123$$";
            bool expected = true;

            bool actual = PasswordChecker.ValidatePassword(password);


            Assert.AreEqual(expected, actual);
        }
        [TestMethod()]
        public void TestMethod2()
        {
            string password = "ASDQWE123$";
            bool expected = false;



            bool actual = PasswordChecker.ValidatePassword(password);

            Assert.AreEqual( expected, actual);
        }
    }
}
